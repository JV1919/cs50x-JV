#include<stdio.h>
#include<cs50.h>

int main(void)
{
 long long z = get_int("credit card number: ");   //z is credit card number
 int zr = 0;                                //zr is the reverse of the credit card number, example: z=123; zr = 321
 int digits = 0;
 while (z > 0)
 {
    zr = z % 10;
    printf("%i",zr);
    z = z / 10;
    digits++;
 }
 printf("\n%i",digits);
 if (digits == 16)
 {
    printf("mastercard/visa");
 }
 else
 {
    if (digits == 15)
    {
        printf("american express");
    }
    else
    {
        if (digits == 13)
        {
            printf("visa");
        }
        else{
            printf("INVALID");
        }
    }
 }
}
