#include<stdio.h>
#include<cs50.h>
#include<string.h>
#include<ctype.h>

int main(int argc, string argv[])
{
    printf("hallo, %s\n",argv[2]);
    printf("argc = %i\n",argc);
    return 0;
}
