#include<stdio.h>
#include<cs50.h>

int main(void)
{
    for (int i = 0; i<=3; i++)
    {
        printf("#");
        printf("%i\n",i);
    }
}

