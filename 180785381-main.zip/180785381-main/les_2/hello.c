#include<stdio.h>
#include<cs50.h>

int main(void)
{
    string antwoord = get_string("wat is je naam? ");
    printf("hallo, %s\n", antwoord);
}
