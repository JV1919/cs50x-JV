#include<stdio.h>
#include<cs50.h>

int main(void)
{
//AANTAL SCORES
    int n = 5;
    float gemiddelde(int lengte, int arrey[]);

    //scores
    int j = 1;
    int score[n];
    for (int i = 0; i<3; i++)
    {
        score[i] = get_int("score %i: ",j);
        j++;
    }


    //gemiddelde van de scores
    printf("het gemiddelde is %f\n", gemiddelde(n,score));
}

float gemiddelde(int lengte, int arrey[])
{
    int som = 0;
    for(int i = 0; i < lengte; i++)
    {
        som = som + arrey[i];
    }
    return som/(float)lengte;
}
