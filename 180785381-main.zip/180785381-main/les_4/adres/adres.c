#include <stdio.h>
#include <cs50.h>

int main (void)
{
    char *s = "HI!";
    int t = get_int("amount of pointer u want printed: ");
    printf("%c\n",*s);
    printf("%c\n",*s+1);
    printf("%c\n",*s+2);
    printf("%c\n",*s+3);
    printf("%c\n",*s+4);
    printf("%p\n",&s[0]);
    printf("%p\n",&s[1]);
    printf("%p\n",&s[2]);
    printf("%p\n",&s[3]);
    printf("%p\n",&s[4]);
    printf("%p\n",&s[5]);
    printf("\n\n\n\n\n\n\n\n");
    for(int i=0; i<t; i++)
    {
        printf("%p\n",&s[i]);
    }
}
