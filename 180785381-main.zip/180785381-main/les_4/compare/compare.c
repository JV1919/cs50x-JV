#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

int main(void)
{
    // string a = get_string("first string: ");
    // string b = get_string("second string: ");
    // string c = a;
    // string d = b;
    // c[0] = toupper (c[0]);
    // c[0] = toupper (c[0]);
    // d[0] = toupper (d[0]);
    // d[0] = toupper (d[0]);
    // if (strcmp(a,b)== 0)
    // {
    //     printf("\n%s = %s\n", a, b);
    // }
    // else
    // {
    //     printf("\n%s =/= %s\n", a, b);
    // }
    // for(int i =0; i< 20; i++)
    // {
    //     printf("\n");
    // }



    string s = get_string("zin1: ");
    string t = malloc(strlen(s) + 1);
    strcpy(t,s);
    t[0] = toupper(t[0]);
    printf("s:%s\nt:%s\n", s, t);
    free(t);
    for(int i = 0; i< i+1; i++)
    {
        string idk = get_string("les_4/ $ ");
    }
}
