#include <stdio.h>

int main (void)
{
    char s[400];
    // char *s = NULL;
    printf("geef een tekst: ");
    scanf("%s", s);
    printf("s is gelijk aan = %s\n",s);
}
