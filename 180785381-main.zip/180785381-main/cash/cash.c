#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int n = 0;
    int c = 0;
    int XXV = 0;
    int X = 0;
    int V = 0;
    int I = 0;
    do
    {
        n = get_int("change owed: ");
    }
    while (n < 0);

        while (n > 0)
        {
            if (n >= 25)
            {
                c++;
                XXV++;
                n = n-25;
            }
            else
            {
                if (n >= 10)
                {
                    c++;
                    X++;
                    n = n-10;
                }
                else
                {
                    if(n >= 5)
                    {
                        c++;
                        V++;
                        n = n-5;
                    }
                    else
                    {
                        if(n >= 1)
                        {
                            c++;
                            I++;
                            n = n-1;
                        }
                    }
                }
            }
        }
        printf("COINS:%i, REST:%i\n",c,n);
        printf("%i x 25c; %i x 10c; %i x 5c; %i x 1c\n",XXV,X,V,I);
}

