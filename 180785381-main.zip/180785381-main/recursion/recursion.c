// jasper verhasselt

#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void draw(int n);

int main(void)
{
    int hoogte = 0;
    do
    {
        hoogte = get_int("how high do u want your piramid? (1-8): ");
        if(hoogte < 1)
        {
            printf("positive numbers only!\n");
        }
    }
    while (hoogte < 1 || hoogte > 8);

    draw(hoogte);
}

void draw(int n)
{
    if (n<=0)
    {
        return;
    }
    draw(n-1);

    for (int i = 0; i < n; i++)
    {
    printf("#");
    }
}

