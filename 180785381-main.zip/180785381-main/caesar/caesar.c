// jasper verhasselt

#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, string argv[])
{
    if (argc != 2) // kijkt of er strict 1 argv is
    {
        return 1; // exit
    }
    for (int j = 0; j < strlen(argv[1]); j++) // herhaal voor elk character
    {
        if (!isdigit(argv[1][j])) // kijkt of argv numeriek is
        {
            return 1; // exit
        }
    }
    string a = get_string("word: "); // vraagt om het woord
    int k = atoi(argv[1]); // maakt een int aan die gebruikt wordt om makkelijker te rekenen, k =
                           // key
    if (k < 1)             // kijkt of de key 1 of hoger is
    {
        return 1; // exit
    }
    char d; // maakt een character aan dat wordt gebruikt als cipher character
    printf("ciphertext: ");
    for (int i = 0; i < strlen(a); i++) // zorgt ervoor dat dit voor elke letter gebeurt
    {
        char c = a[i];
        // printf("%c\n",c);
        if (c <= 'z' && c >= 'a') // kleine letters
        {
            d = (c - 'a' + k) % 26 + 'a'; // veranderd het character, %26+'a' zorgt ervoor dat het
                                          // altijd een letter blijft
            // printf("%c\n",d);
            printf("%c", d);
        }
        else if (c <= 'Z' && c >= 'A') // grote letters
        {
            d = (c - 'A' + k) % 26 + 'A'; // veranderd het character, %26+'A' zorgt ervoor dat het
                                          // altijd een letter blijft
            // printf("%c\n",d);
            printf("%c", d);
        }
        else // indien het geen letter is, wordt het gewoon geprint
        {
            printf("%c", c);
        }
    }
    printf("\n"); // print een lijn als laatste zodat het volgende commando op een nieuwe lijn staat
}
