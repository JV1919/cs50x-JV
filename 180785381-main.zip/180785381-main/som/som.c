// jasper verhasselt

#include <stdio.h> //include the stdio library

int sum(int a, int b);

int main(void)
{
    int number1[5] = {1, 2, 3, 4, 5};  // arrey 1: first set of numbers
    int number2[5] = {6, 7, 8, 9, 10}; // arrey 2: second set of numbers
    int number[5];
    for (int i = 0; i < 5; i++) // loop the following
    {
        number[i] = sum(number1[i], number2[i]); // add arrey 1 to arrey 2
        printf("de som van %i en %i is %i\n", number1[i], number2[i], number[i]); // print result
    }
}

int sum(int a, int b) // add arrey 1 to arrey 2
{
    return a + b; // return arrey 1 + arrey 2
}
