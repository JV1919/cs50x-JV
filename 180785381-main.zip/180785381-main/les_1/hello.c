#include<stdio.h>
#include<cs50.h>

int main(void)
{
    string antwoord = get_string("wat is je naam? ");
    printf("hallo, %s", antwoord);
    printf("\n");
    int x = get_int("getal 1: ");
    int y = get_int("getal2 : ");
    if(x < y)
    {
        printf("x is kleiner dan y\n");
    }
    else
    {
        if(x > y)
        {
            printf("x is groter dan y\n");
        }
        else
        {
            printf("x en y zijn hetzelfde\n");
        }
    }
}
