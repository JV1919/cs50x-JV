#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int counter = 0;
    while (counter ==0)
    {
    char c = get_char("ga je akkoord? ");
        if (c == 'Y')
        {
            printf("Ik ben akkoord\n");
            counter = counter + 1;
        }
        else
        {
            if (c == 'N')
            {
                printf("ben je zeker dat je niet akkoord bent?\n");
            }
            else
            {
                printf("ongeldig antwoord, Y = akkoord, N = niet akkoord\n");
            }

    }

    }

}
