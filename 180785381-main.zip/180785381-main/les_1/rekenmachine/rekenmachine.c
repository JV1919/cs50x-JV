#include<stdio.h>
#include<cs50.h>

int main(void)
{
    int n = 0;
    do
    {
        n = get_int("add = 1 , subtract = 2 , multiply is 3 , divide is 4: ");
    }
    while(n < 1|| n > 4);

    int x = get_int("first number: ");
    int y = get_int("second number: ");
    float z = 0;

    if (n == 1)
    {
        z = (double)x + (double)y;
    }
    else
    {
        if (n == 2)
        {
            z = (double)x-(double)y;
        }
        else
        {
            if(n == 3)
            {
                z = (double)x * (double)y;
            }
            else
            {
                if(n == 4)
                {
                    z = (double)x / (double)y;
                }
            }
        }
    }
    printf("the result is %.6f\n",z);
}
