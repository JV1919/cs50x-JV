// jasper verhasselt

#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    string name;
    string number;
} contacts;

int main(void)
{
    contacts contacten[8];

    contacten[0].name = "dries";
    contacten[0].number = "04741";
    contacten[1].name = "jarne";
    contacten[1].number = "04742";
    contacten[2].name = "jasper";
    contacten[2].number = "+32(0)4743";
    contacten[3].name = "michiel";
    contacten[3].number = "04744";
    contacten[4].name = "jan";
    contacten[4].number = "04745";
    contacten[5].name = "sem";
    contacten[5].number = "04746";
    contacten[6].name = "emmanuel";
    contacten[6].number = "04747";
    contacten[7].name = "kjell";
    contacten[7].number = "04748";
    // string name[] = {"dries","jarne","jasper","michiel","jan","sem","emmanuel","kjell"};//make int with the different names
    // string number [] = {"04741","04742","+32(0)4743","04744","04745","04746","04747","04748"}; //make int with the numbers
    string s = get_string("name you are looking for (sensitive!): ");//ask the name
    bool found = false;//found or not found
    for(int i = 0; i<=7; i++)//repeat the following 7x
    {
        if(strcmp(contacten[i].name,s) == 0)//check if the name is the one we are looking for
        {
            printf("found %s on space %i\n",s,i+1);//print that we found the name and where we found it
            printf("phone number is %s\n",contacten[i].number);
            found = true;//make found true
            return 0;//exit the program
        }
    }
    if (found == false)//check if it is found
    {
        printf("not found\n");//print not found
        return 1;//exit the program
    }
}
