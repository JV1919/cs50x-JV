#include <stdio.h>
#include <cs50.h>

int calculate(int x);

int main(void)
{
    int x = get_int("x= ");
    int y = calculate(x);
    printf("x = %i\n",y);
}


int calculate(int x)
{
    int result = 1;
    for(int i = 1; i<x; i++)
    {
        result = result*i;
    }
    return result;
}
