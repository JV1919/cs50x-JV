#include <stdio.h>
#include <cs50.h>

int calculate(int nr[]);
int searchmax(int unsorted[]);
int searchmin(int unsorted[]);
int aboveAvg(int avg, int nr);
int underAvg(int avg, int nr);

int main(void)
{
    int temperature[7];
    for(int i=0; i < 7; i++)
    {
        int j = i + 1;
        temperature[i] = get_int("temperature%i (in °C): ",j);
    }
    int avg = calculate(temperature);
    int max = searchmax(temperature);
    int min = searchmin(temperature);
    for(int k = 0; k<7; k++)
    {
        if(aboveAvg(avg, temperature[k]) != false)
                    printf("%i,",aboveAvg(avg, temperature[k]));
    }
        printf("are above average\n");
    for(int l = 0; l<7; l++)
    {
        if(underAvg(avg, temperature[l]) != false)
                    printf("%i,",underAvg(avg, temperature[l]));
    }
        printf("are under average\n");

    printf("average is %i\nmin is %i and max is %i\n",avg,min,max);

}


int calculate(int nr[])
{
    int sum = 0;
    for(int i=0; i< 7; i++)
    {
        sum += nr[i];
    }
    int avg = sum/7;
    return avg;
}


int searchmax(int unsorted[])
{
    int max= 0;
    for (int i=0; i<7; i++)
    {
        if(unsorted[i] > max)
            max = unsorted[i];
    }
    return max;
}


int searchmin(int unsorted[])
{
    int min = 0;
    for (int i=0; i<7; i++)
    {
        if(unsorted[i] < min)
            min = unsorted[i];
    }
    return min;
}


int aboveAvg(int avg, int nr)
{
    if(nr>avg)
        return nr;
    return false;
}


int underAvg(int avg, int nr)
{
    if(nr<avg)
        return nr;
    return false;
}
