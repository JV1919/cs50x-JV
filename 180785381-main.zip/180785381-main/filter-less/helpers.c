#include "helpers.h"
#include <stdio.h>

// Convert image to grayscale
void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    // Loop over all pixels
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            long avg = (image[i][j].rgbtRed + image[i][j].rgbtBlue + image[i][j].rgbtGreen) /3;

            image[i][j].rgbtRed = avg;
            image[i][j].rgbtBlue = avg;
            image[i][j].rgbtGreen = avg;
        }
    }
}

// Convert image to sepia
void sepia(int height, int width, RGBTRIPLE image[height][width])
{
    // Loop over all pixels
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int originalRed = image[i][j].rgbtRed;
            int originalGreen = image[i][j].rgbtGreen;
            int originalBlue = image[i][j].rgbtBlue;
            int sepiaRed = .393 * originalRed + .769 * originalGreen + .189 * originalBlue;
            int sepiaGreen = .349 * originalRed + .686 * originalGreen + .168 * originalBlue;
            int sepiaBlue = .272 * originalRed + .534 * originalGreen + .131 * originalBlue;
            if(sepiaRed >= 255)
            {
                sepiaRed = 255;
            }
            if(sepiaGreen >= 255)
            {
                sepiaGreen = 255;
            }
            if(sepiaBlue >= 255)
            {
                sepiaBlue = 255;
            }

            image[i][j].rgbtRed = sepiaRed;
            image[i][j].rgbtGreen = sepiaGreen;
            image[i][j].rgbtBlue = sepiaBlue;
        }
    }
}

// Reflect image horizontally
void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    // Loop over all pixels
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j< width/2; j++)
        {
            int tempRed = image[i][width-j-1].rgbtRed;
            int tempGreen = image[i][width-j-1].rgbtGreen;
            int tempBlue = image[i][width-j-1].rgbtBlue;

            image[i][width-j-1].rgbtRed = image[i][j].rgbtRed;
            image[i][width-j-1].rgbtGreen = image[i][j].rgbtGreen;
            image[i][width-j-1].rgbtBlue = image[i][j].rgbtBlue;

            image[i][j].rgbtRed = tempRed;
            image[i][j].rgbtGreen = tempGreen;
            image[i][j].rgbtBlue = tempBlue;

        }
    }
}

// Blur image
void blur(int height, int width, RGBTRIPLE image[height][width])
{
    // Create a copy of image
    RGBTRIPLE copy[height][width];
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            copy[i][j] = image[i][j];
        }
    }
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {

            int sumRed = 0;
            int sumGreen = 0;
            int sumBlue = 0;
            int count = 0;
            for (int di = -1; di <= 1; di++)
            {
                for (int dj = -1; dj <= 1; dj++)
                {
                   int ni = i + di;
                   int nj = j + dj;
                   if (ni >= 0 && ni < height && nj >= 0 && nj < width)
                   {
                      sumRed += copy[ni][nj].rgbtRed;
                      sumGreen += copy[ni][nj].rgbtGreen;
                      sumBlue += copy[ni][nj].rgbtBlue;
                      count++;
                  }
             }
            }
            // printf("  red:%i\ngreen:%i\n blue:%i\n",sumRed,sumGreen,sumBlue);
            // printf("%i\n",count);
            image[i][j].rgbtRed = sumRed / count;
            image[i][j].rgbtGreen = sumGreen / count;
            image[i][j].rgbtBlue = sumBlue / count;
            // printf("  red:%i\ngreen:%i\n blue:%i\n",image[i][j].rgbtRed,image[i][j].rgbtGreen,image[i][j].rgbtBlue);


        }
    }
}
                // image[i][j].rgbtRed = (image[i][j].rgbtRed + image[i+1][j].rgbtRed + image[i][j+1].rgbtRed + image[i+1][j+1].rgbtRed) /4;
                // image[i][j].rgbtGreen = (image[i][j].rgbtGreen + image[i+1][j].rgbtGreen + image[i][j+1].rgbtGreen + image[i+1][j+1].rgbtGreen) /4;
                // image[i][j].rgbtBlue = (image[i][j].rgbtBlue + image[i+1][j].rgbtBlue + image[i][j+1].rgbtBlue + image[i+1][j+1].rgbtBlue) /4;
