#include <cs50.h>
#include <ctype.h>
#include <stdio.h>
#include <string.h>

int main(void)
{
    int score1 = 0;
    int score2 = 0;
    int score[26] = {1, 3, 3, 2,  1, 4, 2, 4, 1, 8, 5, 1, 3,
                     1, 1, 3, 10, 1, 1, 1, 1, 4, 4, 8, 4, 10};
    string a = get_string("user 1: ");
    string b = get_string("user2: ");
    for (int i = 0; i < strlen(a); i++)
    {
        char c = a[i];
        char d = tolower(c);
        // printf("%c",c);
        score1 = score1 + score[d - 'a'];
        // printf(" = %i\n",score1);
    }
    for (int j = 0; j < strlen(b); j++)
    {
        char e = b[j];
        char f = tolower(e);
        // printf("%c",e);
        score2 = score2 + score[f - 'a'];
        // printf(" = %i\n",score2);
    }
    if (score1 > score2)
    {
        printf("player 1 wins!");
    }
    else if (score1 < score2)
    {
        printf("player 2 wins!");
    }
    else if (score1 == score2)
    {
        printf("Tie!");
    }
    printf("\n");
}
